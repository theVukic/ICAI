(function () {
  const OUT_SOURCE = "INTERCARS_CAPTURE_PAGE";
  const IN_SOURCE = "INTERCARS_CAPTURE_EXTENSION";

  const TARGET_PARTS = [
    "/BA/products?",
    "/BA/products-details",
    "/BA/product-references-count",
    "/BA/wholesale-prices",
    "/BA/category-path",
  ];

  const selectedMap = new Map();

  let fetchHooked = false;
  let xhrHooked = false;
  let observerStarted = false;
  let lastStatusSignature = "";
  let statusTimer = null;
  let selectionObserverTimer = null;
  let selectionEnabled = false;

  installSelectionStyles();
  announceReady();
  hookFetch();
  hookXHR();
  hookHistory();
  hookVisibility();
  startDomObserver();
  startSelectionObserver();
  bindSelectionClicks();

  scheduleStatusBroadcast(50);
  scheduleStatusBroadcast(400);
  scheduleStatusBroadcast(1200);
  scheduleStatusBroadcast(2500);

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== IN_SOURCE) return;

    if (data.type === "PING_PAGE") {
      announceReady(true);
      return;
    }

    if (data.type === "FORCE_STATUS") {
      announceReady(true);
      syncHighlights();
      return;
    }

    if (data.type === "FETCH_GALLERY_BATCH") {
      handleGalleryBatchRequest(data.payload || {});
      return;
    }

    if (data.type === "APPLY_SELECTION_STATE") {
      applyExternalSelectionState(data.payload || {});
      return;
    }

    if (data.type === "SYNC_SELECTION_STATE") {
      emitSelectionSnapshot();
      syncHighlights();
      return;
    }

    if (data.type === "SET_SELECTION_ENABLED") {
      selectionEnabled = !!data.payload?.enabled;
      syncHighlights();
      announceReady(true);
      return;
    }
  });

  window.addEventListener("load", () => {
    bindSelectionClicks();
    syncHighlights();
    announceReady(true);
  });

  function installSelectionStyles() {
    if (document.getElementById("ic-selection-style")) return;

    const style = document.createElement("style");
    style.id = "ic-selection-style";
    style.textContent = `
      .ic-product-card {
        position: relative !important;
      }

      .ic-product-card.ic-selectable-product {
        cursor: pointer !important;
        transition:
          outline-color .18s ease,
          box-shadow .22s ease,
          background-color .22s ease,
          opacity .22s ease;
      }

      .ic-product-card.ic-selectable-product:hover {
        box-shadow: inset 0 0 0 2px rgba(55, 65, 81, .18) !important;
      }

      .ic-product-card.ic-selected-product {
        outline: 2px solid #374151 !important;
        outline-offset: -2px !important;
        background-color: rgba(55, 65, 81, .10) !important;
        box-shadow:
          inset 0 0 0 9999px rgba(55, 65, 81, .08),
          0 0 0 1px rgba(55, 65, 81, .10) !important;
        opacity: .97 !important;
      }

      .ic-product-card.ic-selected-product::after {
        content: "SELECTED";
        position: absolute;
        top: 8px;
        left: 8px;
        z-index: 2147483646;
        background: rgba(55, 65, 81, .82);
        color: #fff;
        font-size: 11px;
        font-weight: 700;
        border-radius: 999px;
        padding: 4px 8px;
        pointer-events: none;
        letter-spacing: .2px;
        box-shadow: 0 6px 16px rgba(55, 65, 81, .24);
      }
    `;
    document.documentElement.appendChild(style);
  }

  function announceReady(force = false) {
    const payload = buildPageStatus();
    const signature = JSON.stringify(payload);

    if (!force && signature === lastStatusSignature) return;
    lastStatusSignature = signature;
    postToExtension("PAGE_STATUS", payload);
  }

  function buildPageStatus() {
    return {
      ready: true,
      fetchHooked,
      xhrHooked,
      observerStarted,
      selectionEnabled,
      url: location.href,
      title: document.title || "",
      pageNumber: detectPageNumber(),
      visibleProductsCount: detectVisibleProductsCount(),
      selectedCount: selectedMap.size,
      timestamp: new Date().toISOString(),
    };
  }

  function scheduleStatusBroadcast(delay = 0) {
    window.setTimeout(() => announceReady(), delay);
  }

  function bindSelectionClicks() {
    if (document.__icSelectionBound) return;
    document.__icSelectionBound = true;
    document.addEventListener("click", onDocumentClick, true);
  }

  function onDocumentClick(event) {
    if (!selectionEnabled) return;

    const target = event.target;
    if (!(target instanceof Element)) return;
    if (shouldIgnoreClick(target)) return;

    const card = findProductCard(target);
    if (!card) return;

    const product = extractProductCardData(card);
    if (!product?.indexKey) return;

    event.preventDefault();
    event.stopPropagation();

    toggleSelection(product, card);
  }

  function shouldIgnoreClick(target) {
    return !!target.closest(
      "button, input, select, textarea, [role='button'], a[href], .editinplace, .js-add-to-cart-form",
    );
  }

  function toggleSelection(product, card) {
    const key = normalizeKey(product.indexKey);

    if (!key) return;

    if (selectedMap.has(key)) {
      selectedMap.delete(key);
    } else {
      selectedMap.set(key, {
        ...product,
        indexKey: key,
      });
    }

    decorateCard(card, selectedMap.has(key), key);
    emitSelectionChanged();
    syncHighlights();
  }

  function emitSelectionChanged() {
    postToExtension("SELECTION_CHANGED", {
      selected: [...selectedMap.values()],
      url: location.href,
      timestamp: new Date().toISOString(),
    });
    announceReady(true);
  }

  function emitSelectionSnapshot() {
    emitSelectionChanged();
  }

  function applyExternalSelectionState(payload) {
    const selected = Array.isArray(payload?.selected) ? payload.selected : [];
    selectedMap.clear();

    for (const item of selected) {
      const key = normalizeKey(item?.indexKey);
      if (!key) continue;

      selectedMap.set(key, {
        ...item,
        indexKey: key,
      });
    }

    syncHighlights();
    emitSelectionSnapshot();
    announceReady(true);
  }

  function startSelectionObserver() {
    if (!document.documentElement || typeof MutationObserver !== "function")
      return;

    const observer = new MutationObserver(() => {
      if (selectionObserverTimer) clearTimeout(selectionObserverTimer);
      selectionObserverTimer = setTimeout(() => {
        syncHighlights();
      }, 140);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  }

  function syncHighlights() {
    const cards = findAllProductCards();
    const selectedKeys = new Set(selectedMap.keys());

    for (const card of cards) {
      const product = extractProductCardData(card);
      const key = normalizeKey(
        product?.indexKey ||
          card.getAttribute("data-product-index") ||
          card.getAttribute("data-ic-index-key") ||
          card
            .querySelector("[data-ic-index-key]")
            ?.getAttribute("data-ic-index-key") ||
          "",
      );

      if (key) {
        card.setAttribute("data-ic-index-key", key);
      }

      const selected = !!key && selectedKeys.has(key);
      decorateCard(card, selected, key);
    }
  }

  function decorateCard(card, isSelected, key = "") {
    if (!card) return;
    card.classList.add("ic-product-card", "ic-selectable-product");
    if (key) {
      card.setAttribute("data-ic-index-key", key);
    }
    card.classList.toggle("ic-selected-product", !!isSelected);
  }

  function findAllProductCards() {
    return Array.from(
      document.querySelectorAll("div[data-product-index][data-towkod]"),
    );
  }

  function findProductCard(start) {
    return start.closest("div[data-product-index][data-towkod]");
  }

  function extractProductCardData(card) {
    if (!(card instanceof Element)) return null;

    const rawIndexKey =
      card.getAttribute("data-product-index") ||
      card.getAttribute("data-ic-index-key") ||
      card
        .querySelector("[data-ic-index-key]")
        ?.getAttribute("data-ic-index-key") ||
      "";

    const indexKey = normalizeKey(rawIndexKey);
    if (!indexKey) return null;

    const towKod =
      card.getAttribute("data-towkod") ||
      card.querySelector("[data-towkod]")?.getAttribute("data-towkod") ||
      "";

    const imgEl = card.querySelector(
      '[data-testid="productImage"] img, .product-image img',
    );
    const imageUrl =
      imgEl?.getAttribute("src") ||
      imgEl?.getAttribute("data-src") ||
      imgEl?.getAttribute("srcset")?.split(",")?.[0]?.trim()?.split(" ")?.[0] ||
      null;

    const indexText =
      card
        .querySelector(
          '[data-testid="productIndexLink"] span, .product-link span',
        )
        ?.textContent?.trim() || indexKey;

    const brandName =
      card
        .querySelector("[data-clk-listing-standard-item-manufacturer]")
        ?.getAttribute("data-clk-listing-standard-item-manufacturer")
        ?.trim() || "";

    const wholesalePriceText =
      card
        .querySelector('[data-testid="wholesalePrice-new"] .sc-ksltVi')
        ?.textContent?.trim() ||
      card
        .querySelector('[data-testid="wholesalePrice-new"]')
        ?.textContent?.trim() ||
      "";

    card.setAttribute("data-ic-index-key", indexKey);

    return {
      indexKey,
      towKod: String(towKod || "").trim(),
      imageUrl,
      indexText: indexText || null,
      brandName: brandName || null,
      priceText: wholesalePriceText || null,
    };
  }

  function normalizeKey(value) {
    return String(value || "").trim();
  }

  async function handleGalleryBatchRequest(payload) {
    const requestId = payload?.requestId || null;
    const locale = String(payload?.locale || "bs");
    const productCodes = Array.isArray(payload?.productCodes)
      ? payload.productCodes.map((x) => String(x || "").trim()).filter(Boolean)
      : [];

    const results = [];

    for (const productCode of productCodes) {
      const url = `${location.origin}/${locale}/api/product/gallery?productCode=${encodeURIComponent(productCode)}`;

      try {
        const response = await fetch(url, {
          method: "GET",
          credentials: "include",
          headers: {
            Accept: "application/json, text/plain, */*",
            "X-Requested-With": "XMLHttpRequest",
          },
        });

        let text = "";
        let json = null;

        try {
          text = await response.text();
          json = tryParseJson(text);
        } catch (_) {}

        results.push({
          productCode,
          url,
          ok: response.ok,
          status: response.status,
          data: json,
          responseBody: response.ok ? null : limitText(text),
        });
      } catch (err) {
        results.push({
          productCode,
          url,
          ok: false,
          status: 0,
          data: null,
          error: err?.message || "Unknown error",
        });
      }
    }

    postToExtension("GALLERY_BATCH_RESULT", {
      requestId,
      results,
      url: location.href,
      timestamp: new Date().toISOString(),
    });
  }

  function hookFetch() {
    if (fetchHooked) return;
    if (typeof window.fetch !== "function") return;

    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
      const requestInfo = normalizeFetchArgs(args);
      const response = await originalFetch.apply(this, args);

      try {
        if (shouldCapture(requestInfo.url, response)) {
          captureFetchResponse(requestInfo, response);
        }

        if (requestInfo.url && requestInfo.url.includes("/BA/products?")) {
          scheduleStatusBroadcast(50);
          scheduleStatusBroadcast(250);
          scheduleStatusBroadcast(800);
          setTimeout(syncHighlights, 500);
        }
      } catch (_) {}

      return response;
    };

    fetchHooked = true;
    announceReady(true);
  }

  function hookXHR() {
    if (xhrHooked) return;
    if (typeof window.XMLHttpRequest !== "function") return;

    const OriginalXHR = window.XMLHttpRequest;
    const originalOpen = OriginalXHR.prototype.open;
    const originalSend = OriginalXHR.prototype.send;
    const originalSetRequestHeader = OriginalXHR.prototype.setRequestHeader;

    OriginalXHR.prototype.open = function (method, url, async, user, password) {
      this.__icCapture = {
        method: method || "GET",
        url: absolutize(url),
        requestHeaders: {},
      };
      return originalOpen.call(this, method, url, async, user, password);
    };

    OriginalXHR.prototype.setRequestHeader = function (name, value) {
      try {
        if (this.__icCapture) {
          this.__icCapture.requestHeaders[name] = value;
        }
      } catch (_) {}
      return originalSetRequestHeader.call(this, name, value);
    };

    OriginalXHR.prototype.send = function (body) {
      try {
        if (this.__icCapture) {
          this.__icCapture.requestBody = safeBodyPreview(body);
        }
      } catch (_) {}

      this.addEventListener("load", function () {
        try {
          const meta = this.__icCapture || {};
          const url = meta.url || absolutize(this.responseURL || "");
          if (!shouldCapture(url, this)) return;

          const contentType = this.getResponseHeader("content-type") || "";
          const text =
            typeof this.responseText === "string" ? this.responseText : "";

          postToExtension("API_CAPTURE", {
            transport: "xhr",
            method: meta.method || "GET",
            url,
            status: this.status,
            ok: this.status >= 200 && this.status < 300,
            contentType,
            requestHeaders: meta.requestHeaders || {},
            requestBody: meta.requestBody || null,
            responseBody: limitText(text),
            responseJson: tryParseJson(text),
          });

          if (url.includes("/BA/products?")) {
            scheduleStatusBroadcast(50);
            scheduleStatusBroadcast(250);
            scheduleStatusBroadcast(800);
            setTimeout(syncHighlights, 500);
          }
        } catch (_) {}
      });

      return originalSend.call(this, body);
    };

    xhrHooked = true;
    announceReady(true);
  }

  function hookHistory() {
    const wrap = (original) =>
      function (...args) {
        const result = original.apply(this, args);
        scheduleStatusBroadcast(20);
        scheduleStatusBroadcast(200);
        scheduleStatusBroadcast(800);
        setTimeout(syncHighlights, 500);
        return result;
      };

    if (typeof history.pushState === "function") {
      history.pushState = wrap(history.pushState);
    }

    if (typeof history.replaceState === "function") {
      history.replaceState = wrap(history.replaceState);
    }

    window.addEventListener("popstate", () => {
      scheduleStatusBroadcast(20);
      scheduleStatusBroadcast(200);
      scheduleStatusBroadcast(800);
      setTimeout(syncHighlights, 500);
    });
  }

  function hookVisibility() {
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) {
        scheduleStatusBroadcast(50);
        scheduleStatusBroadcast(300);
        setTimeout(syncHighlights, 400);
      }
    });

    window.addEventListener("focus", () => {
      scheduleStatusBroadcast(50);
      scheduleStatusBroadcast(300);
      setTimeout(syncHighlights, 400);
    });
  }

  function startDomObserver() {
    if (observerStarted) return;
    if (!document.documentElement || typeof MutationObserver !== "function")
      return;

    const observer = new MutationObserver(() => {
      if (statusTimer) clearTimeout(statusTimer);
      statusTimer = setTimeout(() => {
        announceReady();
        syncHighlights();
      }, 300);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: false,
    });

    observerStarted = true;
    announceReady(true);
  }

  function detectPageNumber() {
    try {
      const url = new URL(location.href);
      const qp =
        url.searchParams.get("page") ||
        url.searchParams.get("pageNumber") ||
        url.searchParams.get("currentPage");

      if (qp != null && qp !== "") {
        const parsed = Number(qp);
        if (Number.isFinite(parsed) && parsed >= 0) return parsed;
      }
    } catch (_) {}

    return 0;
  }

  function detectVisibleProductsCount() {
    return findAllProductCards().length;
  }

  function normalizeFetchArgs(args) {
    const input = args[0];
    const init = args[1] || {};

    let url = "";
    let method = init.method || "GET";
    let headers = headersToObject(init.headers);
    let body = safeBodyPreview(init.body);

    if (typeof input === "string") {
      url = absolutize(input);
    } else if (
      input &&
      typeof Request !== "undefined" &&
      input instanceof Request
    ) {
      url = absolutize(input.url);
      method = init.method || input.method || method;
      headers = {
        ...headersToObject(input.headers),
        ...headers,
      };
    } else if (input && typeof input.url === "string") {
      url = absolutize(input.url);
    }

    return { url, method, headers, body };
  }

  function headersToObject(headers) {
    const out = {};
    try {
      if (!headers) return out;

      if (headers instanceof Headers) {
        headers.forEach((value, key) => {
          out[key] = value;
        });
        return out;
      }

      if (Array.isArray(headers)) {
        for (const pair of headers) {
          if (Array.isArray(pair) && pair.length >= 2) {
            out[String(pair[0])] = String(pair[1]);
          }
        }
        return out;
      }

      if (typeof headers === "object") {
        for (const [key, value] of Object.entries(headers)) {
          out[key] = String(value);
        }
      }
    } catch (_) {}

    return out;
  }

  function safeBodyPreview(body) {
    try {
      if (body == null) return null;
      if (typeof body === "string") return limitText(body);
      if (body instanceof URLSearchParams) return limitText(body.toString());
      if (typeof body === "object") return JSON.parse(JSON.stringify(body));
      return String(body);
    } catch (_) {
      return "[unserializable body]";
    }
  }

  async function captureFetchResponse(requestInfo, response) {
    const clone = response.clone();
    const contentType = clone.headers.get("content-type") || "";
    const text = await clone.text();

    postToExtension("API_CAPTURE", {
      transport: "fetch",
      method: requestInfo.method || "GET",
      url: requestInfo.url,
      status: clone.status,
      ok: clone.ok,
      contentType,
      requestHeaders: requestInfo.headers || {},
      requestBody: requestInfo.body || null,
      responseBody: limitText(text),
      responseJson: tryParseJson(text),
    });
  }

  function shouldCapture(url, responseLike) {
    if (!url || typeof url !== "string") return false;
    const absoluteUrl = absolutize(url);
    if (!absoluteUrl) return false;

    const matched = TARGET_PARTS.some((part) => absoluteUrl.includes(part));
    if (!matched) return false;

    const status = Number(responseLike?.status || 0);
    if (status && (status < 200 || status >= 300)) return false;

    return true;
  }

  function tryParseJson(text) {
    if (!text || typeof text !== "string") return null;
    try {
      return JSON.parse(text);
    } catch (_) {
      return null;
    }
  }

  function limitText(text) {
    const value = String(text || "");
    const MAX = 1500000;
    if (value.length <= MAX) return value;
    return (
      value.slice(0, MAX) + `\\n/* truncated ${value.length - MAX} chars */`
    );
  }

  function absolutize(url) {
    try {
      return new URL(url, location.href).href;
    } catch (_) {
      return String(url || "");
    }
  }

  function postToExtension(type, payload) {
    window.postMessage(
      {
        source: OUT_SOURCE,
        type,
        payload,
      },
      "*",
    );
  }
})();
