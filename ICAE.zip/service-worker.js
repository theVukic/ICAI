const sessions = new Map();
const pendingGalleryRequests = new Map();
const selectedProductsByTab = new Map();

const LOCAL_TIME_ZONE = "Europe/Sarajevo";
const BASE_URL = "https://ba.e-cat.intercars.eu";
const GALLERY_LOCALE = "bs";
const PERSISTENT_SELECTION_KEY = "ic_global_selection";
const PERSISTENT_CAPTURE_KEY = "ic_global_capture_v2";

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
  } catch (_) {}
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === "API_CAPTURE") {
      const tabId = sender?.tab?.id;
      if (typeof tabId === "number") {
        const session = getSession(tabId, sender?.tab?.url || "");
        const captureResult = captureApiPayload(session, message.payload);
        if (
          captureResult?.stored &&
          captureResult?.entry &&
          captureResult?.bucket
        ) {
          await persistCapturedPayload(
            captureResult.bucket,
            captureResult.entry,
          );
        }
      }

      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "PAGE_STATUS") {
      const tabId = sender?.tab?.id;
      if (typeof tabId === "number") {
        const nextUrl = sender?.tab?.url || "";
        const session = getSession(tabId, nextUrl);
        handlePageStatus(session, nextUrl, message.payload || null);
      }

      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "GALLERY_BATCH_RESULT") {
      const payload = message.payload || {};
      const requestId = payload?.requestId || null;
      const pending = requestId ? pendingGalleryRequests.get(requestId) : null;

      if (pending) {
        pendingGalleryRequests.delete(requestId);
        pending.resolve(payload);
      }

      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "SELECTION_CHANGED") {
      const tabId = sender?.tab?.id;

      if (typeof tabId === "number") {
        const selected = Array.isArray(message.payload?.selected)
          ? message.payload.selected
          : [];

        const normalized = dedupeSelection(selected);
        selectedProductsByTab.set(tabId, normalized);

        await rebuildGlobalSelectionFromTabs();
        broadcastSelectionUpdate();
      }

      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "REQUEST_SELECTION_STATE") {
      const tabId = sender?.tab?.id;
      const selected =
        typeof tabId === "number" ? await getMergedSelection(tabId) : [];

      sendResponse({ ok: true, selected });
      return;
    }

    if (message?.type === "GET_SELECTED_PRODUCTS") {
      const tabId = message.tabId;
      const localItems = selectedProductsByTab.get(tabId) || [];
      const globalItems = await loadGlobalSelection();
      const allItems = mergeSelectionArrays(localItems, globalItems);

      sendResponse({
        ok: true,
        items: allItems,
        localCount: localItems.length,
        globalCount: globalItems.length,
        totalCount: allItems.length,
      });
      return;
    }

    if (message?.type === "REMOVE_SELECTED_PRODUCT") {
      const tabId = message.tabId;
      const indexKey = String(message.indexKey || "").trim();

      const currentLocal = selectedProductsByTab.get(tabId) || [];
      selectedProductsByTab.set(
        tabId,
        currentLocal.filter(
          (x) => String(x?.indexKey || "").trim() !== indexKey,
        ),
      );

      await rebuildGlobalSelectionFromTabs();

      await syncSelectionToTab(tabId);
      broadcastSelectionUpdate();
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "CLEAR_SELECTED_PRODUCTS") {
      const tabId = message.tabId;
      selectedProductsByTab.set(tabId, []);
      await rebuildGlobalSelectionFromTabs();
      await clearPersistentCapture();
      await syncSelectionToTab(tabId);
      broadcastSelectionUpdate();
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "GET_CAPTURE_STATUS") {
      const tabId = message.tabId;
      const session = sessions.get(tabId);
      const mergedSelected = await getMergedSelection(tabId);

      sendResponse({
        ok: true,
        active: !!session,
        stats: session
          ? {
              productsRequests: session.products.length,
              detailsRequests: session.productsDetails.length,
              referencesRequests: session.references.length,
              wholesalePricesRequests: session.wholesalePrices.length,
              categoryPathRequests: session.categoryPaths.length,
            }
          : null,
        pageStatus: session?.pageStatus || null,
        selectedCount: mergedSelected.length,
      });
      return;
    }

    if (message?.type === "CLEAR_CAPTURED") {
      const tabId = message.tabId;
      const session = sessions.get(tabId);

      if (session) {
        session.captureEnabled = true;
        clearSessionData(session, false);
        logInfo(session, "Capture state cleared, watcher still active.");
      }

      await clearPersistentCapture();
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "EXPORT_CAPTURED") {
      const stats = await exportCaptured(message.tabId);
      sendResponse({ ok: true, stats });
      return;
    }

    sendResponse({ ok: false, error: "Unknown message type." });
  })().catch((err) => {
    sendResponse({
      ok: false,
      error: err?.message || "Unknown runtime error.",
    });
  });

  return true;
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  sessions.delete(tabId);
  selectedProductsByTab.delete(tabId);
  await rebuildGlobalSelectionFromTabs();
  broadcastSelectionUpdate();

  for (const [requestId, pending] of pendingGalleryRequests.entries()) {
    if (pending?.tabId === tabId) {
      pendingGalleryRequests.delete(requestId);
      pending.reject(new Error("Tab closed before gallery response arrived."));
    }
  }
});

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  await syncSelectionToTab(tabId);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;

  const session = sessions.get(tabId);
  if (session) {
    session.captureEnabled = true;
    session.tabUrl = tab?.url || session.tabUrl || "";
    session.currentPageKey = buildPageScopeKey(session.tabUrl);
    session.currentCategoryId = extractCategoryIdFromTabUrl(session.tabUrl);
    session.lastSeenAt = getLocalTimestamp();

    logInfo(
      session,
      `Tab reload detected. Watcher still active on: ${session.tabUrl}`,
    );
  }

  await syncSelectionToTab(tabId);
});

async function saveGlobalSelection(items) {
  await chrome.storage.local.set({
    [PERSISTENT_SELECTION_KEY]: {
      items: dedupeSelection(items || []),
      updatedAt: Date.now(),
    },
  });
}

async function loadGlobalSelection() {
  const result = await chrome.storage.local.get([PERSISTENT_SELECTION_KEY]);
  return dedupeSelection(result?.[PERSISTENT_SELECTION_KEY]?.items || []);
}

async function rebuildGlobalSelectionFromTabs() {
  const allItems = [];

  for (const items of selectedProductsByTab.values()) {
    if (Array.isArray(items) && items.length) {
      allItems.push(...items);
    }
  }

  const normalized = dedupeSelection(allItems);
  await saveGlobalSelection(normalized);
  return normalized;
}

function normalizeSelectionItem(item) {
  return {
    indexKey: String(item?.indexKey || "").trim(),
    towKod: item?.towKod ?? null,
    name: item?.name ?? null,
    brandName: item?.brandName ?? null,
    imageUrl: item?.imageUrl ?? null,
    indexText: item?.indexText ?? null,
    priceText: item?.priceText ?? null,
  };
}

function dedupeSelection(items) {
  const map = new Map();

  for (const item of items || []) {
    const normalized = normalizeSelectionItem(item);
    if (!normalized.indexKey) continue;
    map.set(normalized.indexKey, normalized);
  }

  return [...map.values()];
}

function mergeSelectionArrays(localItems, globalItems) {
  const map = new Map();

  for (const item of globalItems || []) {
    const key = String(item?.indexKey || "").trim();
    if (!key) continue;
    map.set(key, normalizeSelectionItem(item));
  }

  for (const item of localItems || []) {
    const key = String(item?.indexKey || "").trim();
    if (!key) continue;
    map.set(key, normalizeSelectionItem(item));
  }

  return Array.from(map.values());
}

async function getMergedSelection(tabId) {
  const localItems = selectedProductsByTab.get(tabId) || [];
  const globalItems = await loadGlobalSelection();
  return mergeSelectionArrays(localItems, globalItems);
}

async function loadPersistentCapture() {
  const result = await chrome.storage.local.get([PERSISTENT_CAPTURE_KEY]);
  const value = result?.[PERSISTENT_CAPTURE_KEY];

  return {
    products: Array.isArray(value?.products) ? value.products : [],
    productsDetails: Array.isArray(value?.productsDetails)
      ? value.productsDetails
      : [],
    references: Array.isArray(value?.references) ? value.references : [],
    wholesalePrices: Array.isArray(value?.wholesalePrices)
      ? value.wholesalePrices
      : [],
    categoryPaths: Array.isArray(value?.categoryPaths)
      ? value.categoryPaths
      : [],
    updatedAt: value?.updatedAt || null,
  };
}

async function savePersistentCapture(capture) {
  await chrome.storage.local.set({
    [PERSISTENT_CAPTURE_KEY]: {
      products: capture.products || [],
      productsDetails: capture.productsDetails || [],
      references: capture.references || [],
      wholesalePrices: capture.wholesalePrices || [],
      categoryPaths: capture.categoryPaths || [],
      updatedAt: Date.now(),
    },
  });
}

async function clearPersistentCapture() {
  await chrome.storage.local.set({
    [PERSISTENT_CAPTURE_KEY]: {
      products: [],
      productsDetails: [],
      references: [],
      wholesalePrices: [],
      categoryPaths: [],
      updatedAt: Date.now(),
    },
  });
}

function dedupeCapturedEntries(entries) {
  const map = new Map();

  for (const entry of entries || []) {
    if (!entry?.url || !entry?.data) continue;
    const key = makeKey(entry.url, entry.data);
    if (!map.has(key)) {
      map.set(key, entry);
    }
  }

  return [...map.values()];
}

async function persistCapturedPayload(bucket, entry) {
  if (!bucket || !entry) return;

  const capture = await loadPersistentCapture();

  if (bucket === "products") {
    capture.products = dedupeCapturedEntries([...capture.products, entry]);
  } else if (bucket === "productsDetails") {
    capture.productsDetails = dedupeCapturedEntries([
      ...capture.productsDetails,
      entry,
    ]);
  } else if (bucket === "references") {
    capture.references = dedupeCapturedEntries([...capture.references, entry]);
  } else if (bucket === "wholesalePrices") {
    capture.wholesalePrices = dedupeCapturedEntries([
      ...capture.wholesalePrices,
      entry,
    ]);
  } else if (bucket === "categoryPaths") {
    capture.categoryPaths = dedupeCapturedEntries([
      ...capture.categoryPaths,
      entry,
    ]);
  }

  await savePersistentCapture(capture);
}

async function syncSelectionToTab(tabId) {
  if (typeof tabId !== "number") return;

  try {
    const merged = await getMergedSelection(tabId);

    await chrome.tabs.sendMessage(tabId, {
      type: "APPLY_SELECTION_STATE",
      payload: {
        selected: merged,
      },
    });
  } catch (_) {}
}

function broadcastSelectionUpdate() {
  chrome.runtime.sendMessage({ type: "SELECTIONS_UPDATED" }, () => {
    void chrome.runtime?.lastError;
  });
}

function freshSeen() {
  return {
    products: new Set(),
    details: new Set(),
    references: new Set(),
    wholesalePrices: new Set(),
    categoryPaths: new Set(),
  };
}

function createSession(tabId, tabUrl) {
  const session = {
    tabId,
    tabUrl: tabUrl || "",
    startedAt: getLocalTimestamp(),
    lastSeenAt: getLocalTimestamp(),
    pageStatus: null,
    products: [],
    productsDetails: [],
    references: [],
    wholesalePrices: [],
    categoryPaths: [],
    errors: [],
    logs: [],
    detachedReason: null,
    seen: freshSeen(),
    currentPageKey: buildPageScopeKey(tabUrl || ""),
    activeProductsRequestUrl: null,
    expectedVisibleCount: null,
    currentPageNumber: null,
    currentCategoryId: extractCategoryIdFromTabUrl(tabUrl || ""),
    currentProductsIds: new Set(),
    captureEnabled: true,
  };

  logInfo(session, `Session created for tab ${tabId}.`);
  if (tabUrl) logInfo(session, `Initial tab URL: ${tabUrl}`);
  return session;
}

function getSession(tabId, tabUrl) {
  if (!sessions.has(tabId)) {
    sessions.set(tabId, createSession(tabId, tabUrl));
  }

  const session = sessions.get(tabId);

  if (tabUrl && session.tabUrl !== tabUrl) {
    session.tabUrl = tabUrl;
    session.currentPageKey = buildPageScopeKey(tabUrl);
    session.currentCategoryId = extractCategoryIdFromTabUrl(tabUrl);
  }

  session.lastSeenAt = getLocalTimestamp();
  return session;
}

function clearSessionData(session, keepLogs = true) {
  session.startedAt = getLocalTimestamp();
  session.lastSeenAt = getLocalTimestamp();
  session.products = [];
  session.productsDetails = [];
  session.references = [];
  session.wholesalePrices = [];
  session.categoryPaths = [];
  session.errors = [];
  session.seen = freshSeen();
  session.activeProductsRequestUrl = null;
  session.currentProductsIds = new Set();

  if (!keepLogs) {
    session.logs = [];
  }
}

function resetSessionForNewPage(session, newUrl) {
  session.tabUrl = newUrl || session.tabUrl || "";
  session.currentPageKey = buildPageScopeKey(session.tabUrl);

  clearSessionData(session, false);

  session.pageStatus = null;
  session.expectedVisibleCount = null;
  session.currentPageNumber = null;
  session.currentCategoryId = extractCategoryIdFromTabUrl(session.tabUrl || "");

  logInfo(session, "Page changed. Session reset for current page only.");
  if (session.tabUrl) {
    logInfo(session, `Active page URL: ${session.tabUrl}`);
  }
}

function handlePageStatus(session, nextUrl, nextStatus) {
  if (!session?.captureEnabled) return;

  const oldPageKey = session.currentPageKey || "";
  const newPageKey = buildPageScopeKey(nextUrl || session.tabUrl || "");
  const pageChanged = !!newPageKey && !!oldPageKey && newPageKey !== oldPageKey;

  if (pageChanged) {
    resetSessionForNewPage(session, nextUrl);
  } else if (nextUrl && session.tabUrl !== nextUrl) {
    session.tabUrl = nextUrl;
    session.currentPageKey = newPageKey;
    session.currentCategoryId = extractCategoryIdFromTabUrl(nextUrl);
    logInfo(session, `Tab URL updated: ${nextUrl}`);
  }

  const previousStatus = JSON.stringify(session.pageStatus || null);
  const currentStatus = JSON.stringify(nextStatus || null);

  if (previousStatus !== currentStatus) {
    session.pageStatus = nextStatus;
    session.lastSeenAt = getLocalTimestamp();
    logInfo(session, "PAGE_STATUS changed.");

    if (nextStatus?.visibleProductsCount != null) {
      const count = Number(nextStatus.visibleProductsCount);
      if (Number.isFinite(count) && count >= 0) {
        session.expectedVisibleCount = count;
        logInfo(session, `Visible products on page: ${count}`);
      }
    }

    if (nextStatus?.pageNumber != null) {
      const pageNumber = Number(nextStatus.pageNumber);
      if (Number.isFinite(pageNumber) && pageNumber >= 0) {
        session.currentPageNumber = pageNumber;
      }
    }
  }
}

function captureApiPayload(session, payload) {
  if (!session?.captureEnabled) {
    return null;
  }

  try {
    const url = String(payload?.url || "");
    if (!url) {
      logWarn(session, "Skipped API_CAPTURE because URL was missing.");
      return null;
    }

    if (!isTargetUrl(url)) return null;

    const status = Number(payload?.status || 0);
    if (status && (status < 200 || status >= 300)) {
      logWarn(
        session,
        `Skipped non-success response: ${status} ${shortenUrl(url)}`,
      );
      return null;
    }

    const json = payload?.responseJson;
    if (json == null || typeof json !== "object") {
      logWarn(
        session,
        `Skipped response because parsed JSON was missing: ${shortenUrl(url)}`,
      );
      return null;
    }

    const result = captureResponse(session, payload);

    if (result?.stored) {
      logInfo(
        session,
        `Stored ${result.bucket} payload. Total: ${result.total}`,
      );
    } else if (result?.duplicate) {
      logInfo(session, `Skipped duplicate ${result.bucket} payload.`);
    }

    session.lastSeenAt = getLocalTimestamp();
    return result;
  } catch (err) {
    pushError(session, {
      stage: "captureApiPayload",
      message: err.message,
    });
    return null;
  }
}

function isTargetUrl(url) {
  return (
    url.includes("/BA/products?") ||
    url.includes("/BA/wholesale-prices")
  );
}

function captureResponse(session, payload) {
  const url = String(payload?.url || "");
  const json = payload?.responseJson;

  if (url.includes("/BA/products?")) {
    const key = makeKey(url, json);

    if (!session.seen.products.has(key)) {
      const entry = buildCapturedEntry(payload);
      session.seen.products.add(key);
      session.products.push(entry);
      session.currentProductsIds = extractProductIdentitySet(
        flattenProductResponses(session.products),
      );
      return {
        stored: true,
        duplicate: false,
        bucket: "products",
        total: session.products.length,
        entry,
      };
    }

    return {
      stored: false,
      duplicate: true,
      bucket: "products",
      total: session.products.length,
    };
  }

  if (url.includes("/BA/wholesale-prices")) {
    const key = makeKey(url, json);
    if (!session.seen.wholesalePrices.has(key)) {
      const entry = buildCapturedEntry(payload);
      session.seen.wholesalePrices.add(key);
      session.wholesalePrices.push(entry);
      return {
        stored: true,
        duplicate: false,
        bucket: "wholesalePrices",
        total: session.wholesalePrices.length,
        entry,
      };
    }

    return {
      stored: false,
      duplicate: true,
      bucket: "wholesalePrices",
      total: session.wholesalePrices.length,
    };
  }

  return { stored: false, duplicate: false, bucket: null, total: 0 };
}

function buildCapturedEntry(payload) {
  return {
    url: String(payload?.url || ""),
    data: payload?.responseJson,
    method: String(payload?.method || "GET").toUpperCase(),
    requestBody: payload?.requestBody ?? null,
    requestHeaders:
      payload?.requestHeaders && typeof payload.requestHeaders === "object"
        ? payload.requestHeaders
        : {},
  };
}

function makeKey(url, json) {
  return `${url}::${JSON.stringify(json).slice(0, 2000)}`;
}

async function exportCaptured(tabId) {
  const session = sessions.get(tabId);

  if (!session) {
    throw new Error("Nema uhvaćenih podataka za ovaj tab.");
  }

  const selectedItems = await getMergedSelection(tabId);

  if (!selectedItems.length) {
    throw new Error("Nema selektovanih artikala za export.");
  }

  logInfo(
    session,
    `Export started for tab ${tabId}. Selected items: ${selectedItems.length}`,
  );

  return buildAndDownloadJson(session, selectedItems);
}

function filterProductsBySelection(products, selectedItems) {
  const selectedKeys = new Set(
    (selectedItems || [])
      .flatMap((x) => [x?.indexKey, x?.towKod])
      .filter(Boolean)
      .map((x) => String(x).trim()),
  );

  if (selectedKeys.size === 0) {
    return [];
  }

  return (products || []).filter((product) => {
    const candidates = [
      product?.index,
      product?.manufacturerNumber,
      product?.towKod,
      product?.id,
      product?.catalogItemId,
    ]
      .filter(Boolean)
      .map((x) => String(x).trim());

    return candidates.some((candidate) => selectedKeys.has(candidate));
  });
}

async function buildAndDownloadJson(session, selectedItems) {
  logInfo(session, "Loading persistent captured responses.");
  const persistent = await loadPersistentCapture();
  const allProductsResponses = dedupeCapturedEntries([
    ...session.products,
    ...persistent.products,
  ]);
  const capturedWholesaleResponses = dedupeCapturedEntries([
    ...session.wholesalePrices,
    ...persistent.wholesalePrices,
  ]);
  const allWholesaleResponses = capturedWholesaleResponses;

  logInfo(session, "Merging products and wholesale responses.");
  const mergedProducts = flattenProductResponses(allProductsResponses);
  const workingProducts = filterProductsBySelection(
    mergedProducts,
    selectedItems,
  );
  logInfo(session, `Merged products: ${mergedProducts.length}`);
  logInfo(session, `Selected products: ${workingProducts.length}`);
  logInfo(session, `Wholesale price responses: ${allWholesaleResponses.length}`);

  if (workingProducts.length === 0) {
    throw new Error("Nema selektovanih artikala za export.");
  }

  const galleryMap = await fetchGalleryForProductsFromPage(
    session.tabId,
    workingProducts,
    session,
  );
  const catalog = buildCatalogFromProducts(
    workingProducts,
    allWholesaleResponses,
    galleryMap,
  );
  const jsonText = JSON.stringify(catalog, null, 2);
  const dataUrl = `data:application/json;charset=utf-8,${encodeURIComponent(jsonText)}`;
  const filename = buildJsonName();

  await chrome.downloads.download({
    url: dataUrl,
    filename,
    saveAs: true,
  });

  logInfo(session, `Export completed successfully: ${filename}`);

  return {
    productsRequests: allProductsResponses.length,
    detailsRequests: 0,
    referencesRequests: 0,
    wholesalePricesRequests: allWholesaleResponses.length,
    categoryPathRequests: 0,
    productsCount: workingProducts.length,
    selectedProductsCount: workingProducts.length,
    detailsCount: 0,
    referencesCount: 0,
    wholesalePricesCount: allWholesaleResponses.length,
    categoryPathsCount: 0,
    galleryProducts: galleryMap.size,
    imagesDownloaded: 0,
    finalItems: catalog.items.length,
  };
}

function buildCatalogFromProducts(products, wholesaleEntries, galleryMap) {
  const items = [];
  const seenFinalKeys = {
    id: new Set(),
    towKod: new Set(),
    index: new Set(),
  };

  for (const product of products) {
    const productId = product?.id ?? product?.catalogItemId ?? null;
    const productTowKod = product?.towKod ?? null;
    const productIndex = product?.index ?? null;

    const duplicate =
      (productId && seenFinalKeys.id.has(productId)) ||
      (productTowKod && seenFinalKeys.towKod.has(productTowKod)) ||
      (productIndex && seenFinalKeys.index.has(productIndex));

    if (duplicate) continue;

    if (productId) seenFinalKeys.id.add(productId);
    if (productTowKod) seenFinalKeys.towKod.add(productTowKod);
    if (productIndex) seenFinalKeys.index.add(productIndex);

    const price = findPriceForProduct(product, wholesaleEntries);

    items.push({
      towKod: productTowKod,
      index: productIndex,
      nameB2B: product?.nameB2B ?? null,
      brandName: product?.brandName ?? null,
      images: galleryMap.get(productTowKod || "") || normalizeProductImages(product),
      technicalDescription: product?.technicalDescription ?? null,
      status: product?.status ?? null,
      retailPrice: pickRetailPriceFromWholesale(price),
      currencyCode: pickCurrencyCodeFromWholesale(price, product),
    });
  }

  return {
    generatedAt: getLocalTimestamp(),
    timeZone: `${LOCAL_TIME_ZONE} (Banja Luka, GMT+1/GMT+2 DST)`,
    totalItems: items.length,
    items,
  };
}

function findPriceForProduct(product, wholesaleEntries) {
  const idCandidates = [
    product?.id,
    product?.catalogItemId,
    product?.productId,
    product?.towKod,
    product?.index,
    product?.manufacturerNumber,
  ]
    .filter(Boolean)
    .map(String);

  for (const entry of wholesaleEntries || []) {
    const matched = findMatchInPriceNode(entry?.data, idCandidates);
    if (matched) return matched;
  }

  return null;
}

function findMatchInPriceNode(node, idCandidates, inheritedIds = []) {
  if (Array.isArray(node)) {
    for (const item of node) {
      const matched = findMatchInPriceNode(item, idCandidates, inheritedIds);
      if (matched) return matched;
    }
    return null;
  }

  if (!node || typeof node !== "object") return null;

  const localIds = extractPriceNodeIds(node);
  const combinedIds = [...new Set([...inheritedIds, ...localIds])];
  const gross = extractGrossPrice(node);

  if (gross != null && combinedIds.some((id) => idCandidates.includes(id))) {
    return {
      gross,
      currencyCode: extractCurrencyCode(node),
      source: node,
    };
  }

  for (const value of Object.values(node)) {
    const matched = findMatchInPriceNode(value, idCandidates, combinedIds);
    if (matched) return matched;
  }

  return null;
}

function pickWholesalePriceData(price, product) {
  const empty = {
    quantity: 1,
    currencyCode: "BAM",
    vatRate: null,
    wholesalePrice: {
      net: null,
      gross: null,
      vat: null,
    },
  };

  if (!price || typeof price !== "object") {
    return {
      ...empty,
      priceFound: false,
      priceSourceKey: product?.towKod || product?.index || null,
    };
  }

  const source = price?.source || price;
  const wholesalePrice =
    source?.wholesalePrice ||
    source?.price?.wholesalePrice ||
    source?.wholesalePriceData?.wholesalePrice ||
    (source?.net != null || source?.gross != null || source?.vat != null
      ? {
          net: source?.net ?? null,
          gross: source?.gross ?? null,
          vat: source?.vat ?? null,
        }
      : null);

  return {
    quantity:
      source?.wholesalePriceData?.quantity ?? source?.quantity ?? 1,
    currencyCode:
      price?.currencyCode ??
      extractCurrencyCode(source) ??
      product?.wholesalePriceData?.currencyCode ??
      product?.currencyCode ??
      product?.currency ??
      "BAM",
    vatRate:
      source?.wholesalePriceData?.vatRate ??
      source?.vatRate ??
      source?.vatPercent ??
      source?.taxRate ??
      null,
    wholesalePrice: wholesalePrice || empty.wholesalePrice,
    priceFound: !!wholesalePrice,
    priceSourceKey:
      source?.towKod ||
      source?.index ||
      source?.manufacturerNumber ||
      source?.id ||
      product?.towKod ||
      product?.index ||
      null,
  };
}

function pickRetailPriceFromWholesale(price) {
  const source = price?.source || price;
  const gross =
    price?.gross ??
    source?.wholesalePrice?.gross ??
    source?.price?.wholesalePrice?.gross ??
    source?.wholesalePriceData?.wholesalePrice?.gross ??
    source?.gross ??
    source?.grossPrice ??
    source?.priceGross ??
    null;

  return gross != null && Number.isFinite(Number(gross)) ? Number(gross) : null;
}

function pickCurrencyCodeFromWholesale(price, product) {
  const source = price?.source || price;
  return (
    price?.currencyCode ??
    source?.wholesalePriceData?.currencyCode ??
    source?.currencyCode ??
    source?.currency ??
    product?.wholesalePriceData?.currencyCode ??
    product?.currencyCode ??
    product?.currency ??
    "BAM"
  );
}

function extractPriceNodeIds(node) {
  if (!node || typeof node !== "object") return [];

  return [
    node?.id,
    node?.catalogItemId,
    node?.productId,
    node?.productCode,
    node?.towKod,
    node?.towkod,
    node?.index,
    node?.manufacturerNumber,
    node?.articleIndex,
    node?.articleNumber,
    node?.sku,
    node?.code,
  ]
    .filter(Boolean)
    .map(String);
}

function extractGrossPrice(node) {
  if (!node || typeof node !== "object") return null;

  const direct =
    node?.wholesalePrice?.gross ??
    node?.price?.wholesalePrice?.gross ??
    node?.wholesalePriceData?.wholesalePrice?.gross ??
    node?.gross ??
    node?.grossPrice ??
    node?.priceGross ??
    null;

  if (direct != null && Number.isFinite(Number(direct))) {
    return Number(direct);
  }

  return null;
}

function extractCurrencyCode(node) {
  if (!node || typeof node !== "object") return null;

  const currency =
    node?.wholesalePriceData?.currencyCode ??
    node?.currencyCode ??
    node?.currency ??
    node?.price?.currencyCode ??
    null;

  return currency ? String(currency) : null;
}

function getIdentityKeys(item) {
  const keys = [];
  if (item?.id) keys.push(`id:${item.id}`);
  if (item?.catalogItemId) keys.push(`id:${item.catalogItemId}`);
  if (item?.productId) keys.push(`id:${item.productId}`);
  if (item?.towKod) keys.push(`towKod:${item.towKod}`);
  if (item?.index) keys.push(`index:${item.index}`);
  if (item?.manufacturerNumber) {
    keys.push(`manufacturerNumber:${item.manufacturerNumber}`);
  }
  return keys;
}

function buildIdentityMap(items) {
  const map = new Map();

  for (const item of items || []) {
    for (const key of getIdentityKeys(item)) {
      if (!map.has(key)) map.set(key, item);
    }
  }

  return map;
}

function findByKeys(map, keys) {
  for (const key of keys) {
    if (map.has(key)) return map.get(key);
  }
  return null;
}

function buildCategoryPathMap(entries) {
  const map = new Map();

  for (const entry of entries || []) {
    const leafId = String(entry?.leafId || "").trim();
    const path = Array.isArray(entry?.path) ? entry.path : [];

    if (!leafId || !path.length) continue;

    const existing = map.get(leafId);
    if (!existing || path.length > existing.length) {
      map.set(leafId, path);
    }
  }

  return map;
}

function flattenProductResponses(entries) {
  const out = [];
  const seen = {
    id: new Set(),
    towKod: new Set(),
    index: new Set(),
    fallback: new Set(),
  };

  for (const entry of entries || []) {
    const data = entry?.data;
    const items =
      data?.products || data?.items || data?.data || data?.results || [];

    if (!Array.isArray(items)) continue;

    for (const item of items) {
      const id = item?.id || item?.catalogItemId || null;
      const towKod = item?.towKod || null;
      const index = item?.index || null;

      const duplicate =
        (id && seen.id.has(id)) ||
        (towKod && seen.towKod.has(towKod)) ||
        (index && seen.index.has(index));

      if (duplicate) continue;

      if (id) seen.id.add(id);
      if (towKod) seen.towKod.add(towKod);
      if (index) seen.index.add(index);

      if (!id && !towKod && !index) {
        const fallbackKey = JSON.stringify(item);
        if (seen.fallback.has(fallbackKey)) continue;
        seen.fallback.add(fallbackKey);
      }

      out.push(item);
    }
  }

  return out;
}

function flattenDetailResponses(entries) {
  const out = [];
  const seen = new Set();

  for (const entry of entries || []) {
    const data = entry?.data;
    const items = Array.isArray(data)
      ? data
      : Array.isArray(data?.items)
        ? data.items
        : [data];

    for (const item of items) {
      if (!item) continue;

      const key =
        item?.id ||
        item?.catalogItemId ||
        item?.productId ||
        item?.towKod ||
        item?.index ||
        item?.manufacturerNumber ||
        JSON.stringify(item);

      if (!seen.has(key)) {
        seen.add(key);
        out.push(item);
      }
    }
  }

  return out;
}

function flattenReferenceResponses(entries) {
  const out = [];
  const seen = new Set();

  for (const entry of entries || []) {
    const data = entry?.data;
    const items = Array.isArray(data)
      ? data
      : Array.isArray(data?.items)
        ? data.items
        : [data];

    for (const item of items) {
      if (!item) continue;

      const key =
        item?.id ||
        item?.catalogItemId ||
        item?.productId ||
        item?.towKod ||
        item?.index ||
        item?.manufacturerNumber ||
        JSON.stringify(item);

      if (!seen.has(key)) {
        seen.add(key);
        out.push(item);
      }
    }
  }

  return out;
}

function flattenGenericResponses(entries) {
  const out = [];
  const seen = new Set();

  for (const entry of entries || []) {
    const data = entry?.data;

    if (Array.isArray(data)) {
      for (const item of data) {
        if (!item) continue;
        const key = makeObjectKey(item);
        if (!seen.has(key)) {
          seen.add(key);
          out.push(item);
        }
      }
      continue;
    }

    if (Array.isArray(data?.items)) {
      for (const item of data.items) {
        if (!item) continue;
        const key = makeObjectKey(item);
        if (!seen.has(key)) {
          seen.add(key);
          out.push(item);
        }
      }
      continue;
    }

    if (data && typeof data === "object") {
      const key = makeObjectKey(data);
      if (!seen.has(key)) {
        seen.add(key);
        out.push(data);
      }
    }
  }

  return out;
}

function flattenCategoryPathResponses(entries, sessionCategoryId = null) {
  const out = [];
  const seen = new Set();

  for (const entry of entries || []) {
    const url = entry?.url || "";
    const data = entry?.data;

    let leafIds = extractCategoryIdsFromUrl(url, data);

    // FIX: fallback ako API nije dao leafId
    if ((!leafIds || leafIds.length === 0) && sessionCategoryId) {
      leafIds = [sessionCategoryId];
    }

    const pathCandidates = extractCategoryPathCandidates(data);

    if (!leafIds.length || !pathCandidates.length) continue;

    for (const leafId of leafIds) {
      for (const path of pathCandidates) {
        if (!Array.isArray(path) || path.length === 0) continue;

        const normalizedPath = path
          .map((node) => normalizeCategoryNode(node))
          .filter((node) => node && (node.id || node.name));

        if (!normalizedPath.length) continue;

        const key = `${leafId}::${JSON.stringify(normalizedPath)}`;
        if (seen.has(key)) continue;

        seen.add(key);

        out.push({
          leafId: String(leafId),
          path: normalizedPath,
        });
      }
    }
  }

  return out;
}

function extractCategoryPathCandidates(data) {
  const out = [];
  collectCategoryPathCandidates(data, out);
  return out.filter(
    (path) =>
      Array.isArray(path) &&
      path.length > 0 &&
      path.some((node) => node && typeof node === "object"),
  );
}

function collectCategoryPathCandidates(value, out, depth = 0) {
  if (!value || depth > 6) return;

  if (Array.isArray(value)) {
    const looksLikePath =
      value.length > 0 &&
      value.every(
        (item) =>
          item &&
          typeof item === "object" &&
          ("id" in item ||
            "name" in item ||
            "categoryId" in item ||
            "label" in item),
      );

    if (looksLikePath) {
      out.push(value);
    }

    for (const item of value) {
      collectCategoryPathCandidates(item, out, depth + 1);
    }
    return;
  }

  if (typeof value !== "object") return;

  const directKeys = [
    "path",
    "categoryPath",
    "breadcrumbs",
    "items",
    "nodes",
    "categories",
    "result",
    "data",
  ];

  for (const key of directKeys) {
    if (key in value) {
      collectCategoryPathCandidates(value[key], out, depth + 1);
    }
  }

  for (const nested of Object.values(value)) {
    if (nested && typeof nested === "object") {
      collectCategoryPathCandidates(nested, out, depth + 1);
    }
  }
}

function normalizeCategoryNode(node) {
  if (!node || typeof node !== "object") return null;

  return {
    id:
      node?.id ??
      node?.categoryId ??
      node?.nodeId ??
      node?.genericArticleId ??
      null,
    name: node?.name ?? node?.label ?? node?.title ?? node?.description ?? null,
  };
}

function extractCategoryIdsFromUrl(url, data) {
  const out = new Set();

  try {
    const parsed = new URL(url);
    const paramNames = [
      "categoryId",
      "categoryIds",
      "genericArticleId",
      "genericArticleIds",
      "leafId",
      "leafIds",
      "nodeId",
      "nodeIds",
    ];

    for (const name of paramNames) {
      const raw = parsed.searchParams.get(name);
      if (!raw) continue;

      raw
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean)
        .forEach((x) => out.add(x));
    }
  } catch {}

  [
    data?.id,
    data?.categoryId,
    data?.genericArticleId,
    data?.leafId,
    data?.nodeId,
  ]
    .filter(Boolean)
    .forEach((x) => out.add(String(x)));

  if (Array.isArray(data?.leafIds)) {
    data.leafIds.forEach((x) => out.add(String(x)));
  }
  if (Array.isArray(data?.categoryIds)) {
    data.categoryIds.forEach((x) => out.add(String(x)));
  }

  return [...out];
}

function extractCategoryIdFromTabUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const path = decodeURIComponent(url.pathname);

    const tecdocMatch = path.match(/genart_\d+/i);
    if (tecdocMatch) {
      return `GenericArticle_${tecdocMatch[0].split("_")[1]}`;
    }

    const nodeMatch = path.match(/(?:^|-)75\d{4,}(?:$|-)/);
    if (nodeMatch) {
      return `SalesClassificationNode_${nodeMatch[0].replace(/-/g, "")}`;
    }

    return "";
  } catch {
    return "";
  }
}

function extractProductIdentitySet(products) {
  const out = new Set();

  for (const item of products || []) {
    [
      item?.id,
      item?.catalogItemId,
      item?.productId,
      item?.towKod,
      item?.index,
      item?.manufacturerNumber,
    ]
      .filter(Boolean)
      .map(String)
      .forEach((x) => out.add(x));
  }

  return out;
}

function matchesIdentitySet(item, identitySet) {
  if (!item || !identitySet || identitySet.size === 0) return false;

  const keys = [
    item?.id,
    item?.catalogItemId,
    item?.productId,
    item?.towKod,
    item?.index,
    item?.manufacturerNumber,
  ]
    .filter(Boolean)
    .map(String);

  return keys.some((key) => identitySet.has(key));
}

function matchesPriceForIdentitySet(item, identitySet) {
  if (!item || !identitySet || identitySet.size === 0) return false;

  if (matchesIdentitySet(item, identitySet)) return true;

  return findMatchInPriceNode(item, [...identitySet]) != null;
}

function pickBestImageUrl(imageObj) {
  if (!imageObj || typeof imageObj !== "object") return null;

  const raw =
    imageObj["1200x1200"] ||
    imageObj["600x600"] ||
    imageObj["300x300"] ||
    imageObj["150x150"] ||
    imageObj["100x100"] ||
    Object.values(imageObj).find((v) => typeof v === "string");

  return toAbsoluteUrl(raw);
}

async function fetchGalleryForProductsFromPage(tabId, products, session) {
  const out = new Map();
  const productCodes = [
    ...new Set(
      (products || [])
        .map((product) => String(product?.towKod || "").trim())
        .filter(Boolean),
    ),
  ];

  for (const productCode of productCodes) {
    out.set(productCode, []);
  }

  if (productCodes.length === 0) {
    return out;
  }

  const batchSize = 10;

  for (let i = 0; i < productCodes.length; i += batchSize) {
    const batch = productCodes.slice(i, i + batchSize);
    const requestId = makeGalleryRequestId(tabId);

    logInfo(
      session,
      `Requesting gallery batch from page context. Size: ${batch.length}`,
    );

    const payloadPromise = new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        pendingGalleryRequests.delete(requestId);
        reject(new Error(`Gallery batch timeout for request ${requestId}`));
      }, 30000);

      pendingGalleryRequests.set(requestId, {
        tabId,
        resolve: (payload) => {
          clearTimeout(timeoutId);
          resolve(payload);
        },
        reject: (err) => {
          clearTimeout(timeoutId);
          reject(err);
        },
      });
    });

    try {
      await chrome.tabs.sendMessage(tabId, {
        type: "FETCH_GALLERY_BATCH",
        payload: {
          requestId,
          locale: GALLERY_LOCALE,
          productCodes: batch,
        },
      });
    } catch (err) {
      pendingGalleryRequests.delete(requestId);
      throw new Error(
        `Nije moguće poslati gallery zahtjev tabu: ${err.message}`,
      );
    }

    let responsePayload;
    try {
      responsePayload = await payloadPromise;
    } catch (err) {
      for (const productCode of batch) {
        pushError(session, {
          stage: "galleryFetch",
          productCode,
          message: err.message,
        });
      }
      continue;
    }

    const results = Array.isArray(responsePayload?.results)
      ? responsePayload.results
      : [];

    for (const result of results) {
      const productCode = result?.productCode || null;
      const url = result?.url || null;

      if (!productCode) continue;

      if (!result?.ok) {
        pushError(session, {
          stage: "galleryFetch",
          productCode,
          url,
          message: result?.error || `HTTP ${result?.status || 0}`,
        });
        out.set(productCode, []);
        continue;
      }

      const normalized = normalizeGalleryApiImages(result?.data);
      out.set(productCode, normalized);
      logInfo(
        session,
        `Gallery fetched for ${productCode}. Images found: ${normalized.length}`,
      );
    }
  }

  return out;
}

function makeGalleryRequestId(tabId) {
  return `gallery:${tabId}:${Date.now()}:${Math.random()
    .toString(36)
    .slice(2)}`;
}

function normalizeGalleryApiImages(data) {
  if (!Array.isArray(data)) return [];

  return data
    .map((entry, idx) => {
      const zoomUrl = toAbsoluteUrl(entry?.zoom?.url || null);
      const productUrl = toAbsoluteUrl(entry?.product?.url || null);
      const thumbnailUrl = toAbsoluteUrl(entry?.thumbnail?.url || null);
      const url = zoomUrl || productUrl || thumbnailUrl;

      if (!url) return null;

      return {
        position: Number(
          entry?.zoom?.galleryIndex ??
            entry?.product?.galleryIndex ??
            entry?.thumbnail?.galleryIndex ??
            idx + 1,
        ),
        url,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.position - b.position);
}

function normalizeProductImages(product) {
  const rawImages = [];

  const pushImage = (value) => {
    if (!value) return;
    if (typeof value === "string") {
      rawImages.push({ url: value });
      return;
    }
    if (typeof value === "object") {
      rawImages.push(value);
    }
  };

  if (Array.isArray(product?.images)) {
    product.images.forEach(pushImage);
  }

  pushImage(product?.image);
  pushImage(product?.imageUrl);
  pushImage(product?.photoUrl);

  return rawImages
    .map((image, idx) => {
      const url =
        toAbsoluteUrl(image?.url) ||
        toAbsoluteUrl(image?.src) ||
        toAbsoluteUrl(image?.imageUrl) ||
        pickBestImageUrl(image);

      if (!url) return null;

      return {
        position: Number(image?.position ?? image?.galleryIndex ?? idx + 1),
        url,
      };
    })
    .filter(Boolean);
}

function normalizePageUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    url.hash = "";
    return url.toString();
  } catch {
    return rawUrl || "";
  }
}

function buildPageScopeKey(rawUrl) {
  try {
    const url = new URL(rawUrl);
    url.hash = "";
    return `${url.origin}${url.pathname}?${url.searchParams.toString()}`;
  } catch {
    return rawUrl || "";
  }
}

function getLocalTimestamp() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: LOCAL_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(now);

  const map = Object.fromEntries(parts.map((p) => [p.type, p.value]));
  return `${map.year}-${map.month}-${map.day}T${map.hour}:${map.minute}:${map.second}`;
}

function makeObjectKey(item) {
  return (
    item?.towKod ||
    item?.id ||
    item?.catalogItemId ||
    item?.productId ||
    item?.index ||
    item?.manufacturerNumber ||
    JSON.stringify(item)
  );
}

function toAbsoluteUrl(raw) {
  if (!raw || typeof raw !== "string") return null;
  if (raw.startsWith("http://") || raw.startsWith("https://")) return raw;
  if (raw.startsWith("//")) return `https:${raw}`;
  if (raw.startsWith("/")) return `${BASE_URL}${raw}`;
  return null;
}

function guessExtension(url) {
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    if (pathname.endsWith(".png")) return ".png";
    if (pathname.endsWith(".webp")) return ".webp";
    if (pathname.endsWith(".gif")) return ".gif";
    if (pathname.endsWith(".jpeg")) return ".jpeg";
    if (pathname.endsWith(".jpg")) return ".jpg";
    if (pathname.endsWith(".svg")) return ".svg";
    return ".jpg";
  } catch {
    return ".jpg";
  }
}

function sanitize(value) {
  return String(value).replace(/[<>:"/\\|?*\x00-\x1F]/g, "_");
}

function shortenUrl(url, max = 160) {
  if (!url) return "";
  return url.length > max ? `${url.slice(0, max)}...` : url;
}

function buildJsonName() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: LOCAL_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(now);

  const map = Object.fromEntries(parts.map((p) => [p.type, p.value]));
  return `ICAE-${map.year}${map.month}${map.day}-${map.hour}${map.minute}${map.second}.json`;
}

function getSiteNameFromUrl(rawUrl) {
  try {
    const host = new URL(rawUrl).hostname || "site";
    return host.replace(/^www\./i, "").replace(/\./g, "-");
  } catch {
    return "site";
  }
}

function logInfo(session, message) {
  session.logs.push(`[${getLocalTimestamp()}] INFO ${message}`);
}

function logWarn(session, message) {
  session.logs.push(`[${getLocalTimestamp()}] WARN ${message}`);
}

function pushError(session, error) {
  const normalized = {
    time: getLocalTimestamp(),
    stage: error?.stage || "unknown",
    url: error?.url || null,
    productCode: error?.productCode || null,
    message: error?.message || "Unknown error",
  };

  session.errors.push(normalized);
  session.logs.push(
    `[${normalized.time}] ERROR stage=${normalized.stage} productCode=${
      normalized.productCode || "-"
    } url=${normalized.url || "-"} message=${normalized.message}`,
  );
}
