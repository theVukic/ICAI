(function () {
  const RUNTIME_SOURCE = "INTERCARS_CAPTURE_PAGE";
  const EXTENSION_SOURCE = "INTERCARS_CAPTURE_EXTENSION";

  injectPageScript();
  bridgeMessages();

  function injectPageScript() {
    try {
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL("injected.js");
      script.async = false;
      script.onload = () => {
        try {
          script.remove();
        } catch (_) {}
      };
      (document.documentElement || document.head || document.body).appendChild(
        script,
      );
    } catch (err) {
      sendRuntime({
        type: "CAPTURE_ERROR",
        error: `Inject failed: ${err.message}`,
      });
    }
  }

  function bridgeMessages() {
    window.addEventListener("message", (event) => {
      if (event.source !== window) return;

      const data = event.data;
      if (!data || data.source !== RUNTIME_SOURCE) return;

      if (data.type === "API_CAPTURE") {
        sendRuntime({ type: "API_CAPTURE", payload: data.payload });
        return;
      }

      if (data.type === "PAGE_STATUS") {
        sendRuntime({ type: "PAGE_STATUS", payload: data.payload });
        return;
      }

      if (data.type === "GALLERY_BATCH_RESULT") {
        sendRuntime({ type: "GALLERY_BATCH_RESULT", payload: data.payload });
        return;
      }

      if (data.type === "SELECTION_CHANGED") {
        sendRuntime({ type: "SELECTION_CHANGED", payload: data.payload });
        return;
      }

      if (data.type === "REQUEST_SELECTION_STATE") {
        sendRuntime({ type: "REQUEST_SELECTION_STATE", payload: data.payload });
        return;
      }
    });

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message?.type === "PING_PAGE") {
        window.postMessage(
          { source: EXTENSION_SOURCE, type: "PING_PAGE" },
          "*",
        );
        sendResponse({ ok: true });
        return false;
      }

      if (message?.type === "FORCE_STATUS") {
        window.postMessage(
          { source: EXTENSION_SOURCE, type: "FORCE_STATUS" },
          "*",
        );
        sendResponse({ ok: true });
        return false;
      }

      if (message?.type === "FETCH_GALLERY_BATCH") {
        window.postMessage(
          {
            source: EXTENSION_SOURCE,
            type: "FETCH_GALLERY_BATCH",
            payload: message.payload || {},
          },
          "*",
        );
        sendResponse({ ok: true });
        return false;
      }

      if (message?.type === "APPLY_SELECTION_STATE") {
        window.postMessage(
          {
            source: EXTENSION_SOURCE,
            type: "APPLY_SELECTION_STATE",
            payload: message.payload || {},
          },
          "*",
        );
        sendResponse({ ok: true });
        return false;
      }

      if (message?.type === "SYNC_SELECTION_STATE") {
        window.postMessage(
          {
            source: EXTENSION_SOURCE,
            type: "SYNC_SELECTION_STATE",
          },
          "*",
        );
        sendResponse({ ok: true });
        return false;
      }

      if (message?.type === "SET_SELECTION_ENABLED") {
        window.postMessage(
          {
            source: EXTENSION_SOURCE,
            type: "SET_SELECTION_ENABLED",
            payload: message.payload || {},
          },
          "*",
        );
        sendResponse({ ok: true });
        return false;
      }

      if (message?.type === "GET_VISIBLE_PRODUCTS") {
        const items = getVisibleProductsOnPage();
        sendResponse({
          ok: true,
          items,
          count: items.length,
          url: location.href,
        });
        return false;
      }

      return false;
    });
  }

  function getVisibleProductsOnPage() {
    const cards = Array.from(
      document.querySelectorAll("div[data-product-index][data-towkod]"),
    );
    const map = new Map();

    for (const card of cards) {
      const item = extractProductCardData(card);
      if (!item?.indexKey) continue;
      map.set(item.indexKey, item);
    }

    return Array.from(map.values());
  }

  function extractProductCardData(card) {
    if (!(card instanceof Element)) return null;

    const rawIndexKey =
      card.getAttribute("data-product-index") ||
      card.getAttribute("data-ic-index-key") ||
      card
        .querySelector("[data-ic-index-key]")
        ?.getAttribute("data-ic-index-key") ||
      "";

    const indexKey = normalizeKey(rawIndexKey);
    if (!indexKey) return null;

    const towKod =
      card.getAttribute("data-towkod") ||
      card.querySelector("[data-towkod]")?.getAttribute("data-towkod") ||
      "";

    const imgEl = card.querySelector(
      '[data-testid="productImage"] img, .product-image img',
    );
    const imageUrl =
      imgEl?.getAttribute("src") ||
      imgEl?.getAttribute("data-src") ||
      imgEl?.getAttribute("srcset")?.split(",")?.[0]?.trim()?.split(" ")?.[0] ||
      null;

    const indexText =
      card
        .querySelector(
          '[data-testid="productIndexLink"] span, .product-link span',
        )
        ?.textContent?.trim() || indexKey;

    const brandName =
      card
        .querySelector("[data-clk-listing-standard-item-manufacturer]")
        ?.getAttribute("data-clk-listing-standard-item-manufacturer")
        ?.trim() || "";

    const wholesalePriceText =
      card
        .querySelector('[data-testid="wholesalePrice-new"] .sc-ksltVi')
        ?.textContent?.trim() ||
      card
        .querySelector('[data-testid="wholesalePrice-new"]')
        ?.textContent?.trim() ||
      "";

    card.setAttribute("data-ic-index-key", indexKey);

    return {
      indexKey,
      towKod: String(towKod || "").trim(),
      imageUrl,
      indexText: indexText || null,
      brandName: brandName || null,
      priceText: wholesalePriceText || null,
    };
  }

  function normalizeKey(value) {
    return String(value || "").trim();
  }

  function sendRuntime(message) {
    try {
      chrome.runtime.sendMessage(message, () => {
        try {
          void chrome.runtime.lastError;
        } catch (_) {}
      });
    } catch (_) {}
  }
})();
