const panelRoot = document.getElementById("panelRoot");
const panelContent = document.getElementById("panelContent");
const overlayEl = document.getElementById("notIntercarsOverlay");
const listWrap = document.getElementById("listWrap");
const selectedCountPill = document.getElementById("selectedCountPill");
const refreshBtn = document.getElementById("refreshBtn");
const clearBtn = document.getElementById("clearBtn");
const exportBtn = document.getElementById("exportBtn");
const selectionToggle = document.getElementById("selectionToggle");
const selectAllToggle = document.getElementById("selectAllToggle");
const themeToggle = document.getElementById("themeToggle");

let activeTabId = null;
let selectionEnabled = false;
let theme = "light";
let refreshInProgress = false;
let lastRenderSignature = "";

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true,
  });
  return tab;
}

function isIntercarsTab(tab) {
  const url = tab?.url || "";
  return url.includes("intercars.eu") || url.includes("e-cat.intercars.eu");
}

async function getSelection(tabId) {
  return chrome.runtime.sendMessage({
    type: "GET_SELECTED_PRODUCTS",
    tabId,
  });
}

async function getVisibleProducts(tabId) {
  try {
    return await chrome.tabs.sendMessage(tabId, {
      type: "GET_VISIBLE_PRODUCTS",
    });
  } catch (_) {
    return { ok: false, items: [] };
  }
}

async function applySelectionState(tabId, items) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      type: "APPLY_SELECTION_STATE",
      payload: {
        selected: Array.isArray(items) ? items : [],
      },
    });
  } catch (_) {}
}

async function removeSelection(tabId, indexKey) {
  return chrome.runtime.sendMessage({
    type: "REMOVE_SELECTED_PRODUCT",
    tabId,
    indexKey,
  });
}

async function clearSelection(tabId) {
  return chrome.runtime.sendMessage({
    type: "CLEAR_SELECTED_PRODUCTS",
    tabId,
  });
}

async function exportCaptured(tabId) {
  return chrome.runtime.sendMessage({
    type: "EXPORT_CAPTURED",
    tabId,
  });
}

async function pingPage(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "PING_PAGE" });
  } catch (_) {}
}

async function requestSelectionSync(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "SYNC_SELECTION_STATE" });
  } catch (_) {}
}

async function forceStatus(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "FORCE_STATUS" });
  } catch (_) {}
}

async function setSelectionEnabled(tabId, enabled) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      type: "SET_SELECTION_ENABLED",
      payload: { enabled: !!enabled },
    });
  } catch (_) {}
}

async function loadTheme() {
  try {
    const result = await chrome.storage.local.get(["ic_theme"]);
    theme = result?.ic_theme === "dark" ? "dark" : "light";
  } catch (_) {
    theme = "light";
  }
}

async function saveTheme() {
  try {
    await chrome.storage.local.set({ ic_theme: theme });
  } catch (_) {}
}

function normalizeIndexKey(value) {
  return String(value || "").trim();
}

function mergeUniqueItems(primaryItems, secondaryItems) {
  const map = new Map();

  for (const item of secondaryItems || []) {
    const key = normalizeIndexKey(item?.indexKey);
    if (!key) continue;
    map.set(key, item);
  }

  for (const item of primaryItems || []) {
    const key = normalizeIndexKey(item?.indexKey);
    if (!key) continue;
    map.set(key, item);
  }

  return Array.from(map.values());
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function setSelectAllState({ checked = false, disabled = false } = {}) {
  if (!selectAllToggle) return;
  selectAllToggle.checked = !!checked;
  selectAllToggle.disabled = !!disabled;
}

async function getVisibleProductsSafe(tabId) {
  let response = await getVisibleProducts(tabId);
  let items = Array.isArray(response?.items) ? response.items : [];

  if (items.length) {
    return items;
  }

  await forceStatus(tabId);
  await requestSelectionSync(tabId);

  response = await getVisibleProducts(tabId);
  items = Array.isArray(response?.items) ? response.items : [];

  return items;
}

async function syncSelectAllUi(tabId, selectedItems = []) {
  if (tabId == null) {
    setSelectAllState({ checked: false, disabled: true });
    return;
  }

  const visibleItems = await getVisibleProductsSafe(tabId);

  if (!visibleItems.length) {
    setSelectAllState({ checked: false, disabled: false });
    return;
  }

  const visibleKeys = new Set(
    visibleItems
      .map((item) => normalizeIndexKey(item?.indexKey))
      .filter(Boolean),
  );
  const selectedKeys = new Set(
    (selectedItems || [])
      .map((item) => normalizeIndexKey(item?.indexKey))
      .filter(Boolean),
  );

  const allVisibleSelected =
    visibleKeys.size > 0 &&
    Array.from(visibleKeys).every((key) => selectedKeys.has(key));

  setSelectAllState({ checked: allVisibleSelected, disabled: false });
}

function renderItems(items) {
  const safeItems = Array.isArray(items) ? items : [];
  const signature = JSON.stringify(
    safeItems.map((x) => ({
      k: x.indexKey || "",
      p: x.priceText || "",
      b: x.brandName || "",
      i: x.imageUrl || "",
    })),
  );

  if (signature === lastRenderSignature) {
    return;
  }
  lastRenderSignature = signature;

  selectedCountPill.textContent = `Selektovano: ${safeItems.length}`;

  if (!safeItems.length) {
    listWrap.innerHTML = `<div class="empty"><b>NEMA SELEKTOVANIH ARTIKALA</b></div>`;
    return;
  }

  listWrap.innerHTML = safeItems
    .map((item) => {
      const img = item.imageUrl
        ? `<img class="product-thumb" src="${escapeHtml(
            item.imageUrl,
          )}" alt="${escapeHtml(item.indexText || item.indexKey || "")}">`
        : `<div class="product-thumb placeholder"></div>`;

      const index = escapeHtml(item.indexText || item.indexKey || "");
      const brand = escapeHtml(item.brandName || "");
      const price = escapeHtml(item.priceText || "");
      const key = escapeHtml(item.indexKey || "");

      return `
        <div class="product-item" data-index-key="${key}">
          ${img}
          <div class="product-main">
            <div class="product-index">${index}</div>
            <div class="product-brand">${brand}</div>
          </div>
          <div class="product-price">${price}</div>
          <button type="button" class="remove-btn" data-remove-index-key="${key}" title="Obriši">×</button>
        </div>
      `;
    })
    .join("");

  listWrap.querySelectorAll("[data-remove-index-key]").forEach((btn) => {
    btn.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();

      const key = btn.getAttribute("data-remove-index-key");
      if (!key || activeTabId == null) return;

      await removeSelection(activeTabId, key);
      await requestSelectionSync(activeTabId);
      const selection = await getSelection(activeTabId);
      renderItems(selection?.items || []);
      await syncSelectAllUi(activeTabId, selection?.items || []);
    });
  });
}

function applyTheme() {
  document.body.classList.toggle("dark", theme === "dark");
  themeToggle.textContent = theme === "dark" ? "🌙" : "☀";
}

function showNotIntercarsOverlay(show) {
  if (show) {
    overlayEl.classList.add("visible");
    panelContent.classList.add("blurred");
  } else {
    overlayEl.classList.remove("visible");
    panelContent.classList.remove("blurred");
  }
}

async function refreshView(source) {
  if (refreshInProgress) return;
  refreshInProgress = true;

  try {
    const tab = await getActiveTab();

    if (!tab?.id || !isIntercarsTab(tab)) {
      activeTabId = null;
      selectionEnabled = false;
      selectionToggle.checked = false;
      setSelectAllState({ checked: false, disabled: true });
      showNotIntercarsOverlay(true);
      selectedCountPill.textContent = "Selektovano: 0";
      lastRenderSignature = "";
      listWrap.innerHTML = `<div class="empty"><b>OTVORI INTERCARS E-KATALOG!</b></div>`;
      return;
    }

    showNotIntercarsOverlay(false);
    activeTabId = tab.id;

    await pingPage(tab.id);
    await forceStatus(tab.id);
    await requestSelectionSync(tab.id);
    await setSelectionEnabled(tab.id, selectionEnabled);

    const selection = await getSelection(tab.id);
    const items = selection?.items || [];
    renderItems(items);
    await syncSelectAllUi(tab.id, items);
  } finally {
    refreshInProgress = false;
  }
}

themeToggle.addEventListener("click", async () => {
  theme = theme === "light" ? "dark" : "light";
  applyTheme();
  await saveTheme();
});

selectionToggle.addEventListener("change", async () => {
  selectionEnabled = !!selectionToggle.checked;

  if (activeTabId != null) {
    await setSelectionEnabled(activeTabId, selectionEnabled);
    await syncSelectAllUi(
      activeTabId,
      (await getSelection(activeTabId))?.items || [],
    );
  }
});

selectAllToggle.addEventListener("change", async () => {
  if (activeTabId == null) {
    setSelectAllState({ checked: false, disabled: true });
    return;
  }

  const visibleItems = await getVisibleProductsSafe(activeTabId);

  if (!visibleItems.length) {
    setSelectAllState({ checked: false, disabled: false });
    return;
  }

  const currentSelection = await getSelection(activeTabId);
  const currentItems = Array.isArray(currentSelection?.items)
    ? currentSelection.items
    : [];

  const visibleKeys = new Set(
    visibleItems
      .map((item) => normalizeIndexKey(item?.indexKey))
      .filter(Boolean),
  );

  const nextItems = selectAllToggle.checked
    ? mergeUniqueItems(visibleItems, currentItems)
    : currentItems.filter(
        (item) => !visibleKeys.has(normalizeIndexKey(item?.indexKey)),
      );

  await applySelectionState(activeTabId, nextItems);
  await requestSelectionSync(activeTabId);

  const selection = await getSelection(activeTabId);
  const items = selection?.items || [];
  renderItems(items);
  await syncSelectAllUi(activeTabId, items);
});

refreshBtn.addEventListener("click", async () => {
  const tab = await getActiveTab();
  if (!tab?.id) return;

  activeTabId = tab.id;
  selectionEnabled = false;
  selectionToggle.checked = false;
  setSelectAllState({ checked: false, disabled: false });
  await setSelectionEnabled(tab.id, false);

  try {
    await chrome.tabs.reload(tab.id);
  } catch (_) {}

  setTimeout(() => {
    refreshView("manual-refresh").catch(() => {});
  }, 800);
});

clearBtn.addEventListener("click", async () => {
  if (activeTabId == null) return;
  await clearSelection(activeTabId);
  await refreshView("clear");
});

exportBtn.addEventListener("click", async () => {
  if (activeTabId == null) return;

  exportBtn.disabled = true;
  exportBtn.textContent = "Exporting...";

  try {
    const result = await exportCaptured(activeTabId);
    if (!result?.ok) {
      alert(result?.error || "Export nije uspio.");
    }
  } catch (err) {
    alert(err?.message || "Export nije uspio.");
  } finally {
    exportBtn.disabled = false;
    exportBtn.textContent = "EXPORT";
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "SELECTIONS_UPDATED") {
    refreshView("selection-update").catch(() => {});
  }
});

chrome.tabs.onActivated.addListener(() => {
  refreshView("tab-activated").catch(() => {});
});

chrome.tabs.onUpdated.addListener((_tabId, changeInfo) => {
  if (changeInfo.status === "complete") {
    refreshView("tab-updated").catch(() => {});
  }
});

window.addEventListener("beforeunload", () => {
  if (activeTabId != null) {
    chrome.tabs
      .sendMessage(activeTabId, {
        type: "SET_SELECTION_ENABLED",
        payload: { enabled: false },
      })
      .catch?.(() => {});
  }
});

(async function init() {
  await loadTheme();
  applyTheme();
  selectionEnabled = false;
  selectionToggle.checked = false;
  setSelectAllState({ checked: false, disabled: false });
  await refreshView("init");
})();
